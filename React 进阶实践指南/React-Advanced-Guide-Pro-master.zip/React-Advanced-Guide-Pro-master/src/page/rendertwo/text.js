import React from 'react'

export default function index(){
    return <div>hello,let us learn React!</div>
}