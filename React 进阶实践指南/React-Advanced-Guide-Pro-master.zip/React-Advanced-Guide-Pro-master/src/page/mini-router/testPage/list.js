import React from 'react'

export default function List(){
    return <div>
        <li>React.js</li>
        <li>Vue.js</li>
        <li>nodejs</li>
    </div>
}