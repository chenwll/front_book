
import React from 'react'

import HomeOne from './homeOne'

export default function Home(){
    return <div>
        hello,world。
        let us learn React!
        <HomeOne />
    </div>
}