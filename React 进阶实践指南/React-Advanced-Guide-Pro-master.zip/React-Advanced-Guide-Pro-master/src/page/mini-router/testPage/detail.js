import React from 'react'

export default function  Index() {
    return <div>
        <p>小册名称：《React进阶实践指南》</p>
        <p>作者：我不是外星人</p>
    </div>
}