import { observable ,action ,makeObservable } from 'mobx'
class Root{
   constructor(){
      makeObservable(this)
   }
   @observable info={
       name:'xxx',
       mes:'xxx'
   }
   // @observable number = 1
   @action setInfo(info){
      this.info = info
   }
}
export default new Root()