# React-Advanced-Guide-Pro
《React进阶实践指南》——demo项目和代码片段


## 上手简介

全局安装 rux-cli:

````js
npm install rux-cli -g 
````

安装成功后，运行命令：
 
````js
npm start 
````

